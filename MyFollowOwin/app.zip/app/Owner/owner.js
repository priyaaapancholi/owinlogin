"use strict";
var Owner = (function () {
    function Owner() {
    }
    return Owner;
}());
exports.Owner = Owner;
//# sourceMappingURL=owner.js.map