﻿export class Owner {
    
    CompanyName: string;
    WebsiteUrl: string;
    FoundedYear: number;
    Description: string;
}